# PROMPT_DEV_OS_v14_1_NODE_READY

Node/TS prompt OS con:
- Router automático (elige flow y pipeline sin template_key)
- Prefetch policy (budget 2 tools / 800ms) con stubs
- Render Jinja2-compatible (Nunjucks) con strict undefined
- Registry-only + deny runtime templates
- Lockfile SHA256 verificado en runtime
- Pipelines (flow -> agentes) + gates QA + compliance

## Quickstart
```bash
npm i
npm run run
```

## Verify
```bash
npm run verify
```

## Freeze lockfile
```bash
npm run freeze
```


## Runtime profiles (docs vs runtime)

- `profiles/runtime.docs.json` → sets `system.runtime.mode="docs"`
- `profiles/runtime.runtime.json` → sets `system.runtime.mode="runtime"`

You can merge either profile into your `project.json` under `system`.
