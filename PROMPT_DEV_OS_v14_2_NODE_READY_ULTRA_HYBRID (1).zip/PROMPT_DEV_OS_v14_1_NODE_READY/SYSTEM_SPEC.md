# PULSE_PROMPT_DEV_OS_v14_2_ULTRA_HYBRID — SYSTEM SPEC

## Purpose
Hybrid multi-agent OS with **auto-router + prefetch + flow pipelines + gates + snapshot**.
Runs in two modes:
- **DOCS**: passive discovery / documentation synthesis / patch proposals.
- **RUNTIME**: active execution to produce deliverables via pipelines.

## Engine order (runtime)
1) `kernel.router.v2` → sets `system.route.flow_key` (+ rationale, confidence, fallback)
2) `kernel.prefetch_policy.v1` → tool plan + budgets
3) Prefetch executor (stubs) → fills `source.*`
4) Pipeline: `flow_key` → agents rendered sequentially
5) Gates: `agent00.qc.v2` + `agent15.compliance.v2`
6) Snapshot: `agent00.meta_archivist.v1`

## Namespace contract (strict)
- **system**: runtime, route, compliance
- **passthrough**: normalized inputs
- **source**: prefetch context (summaries/documents/memory)
- **tools**: tool stubs (replaceable)

## Security (hard rules)
- **registry-only**: deny runtime templates
- **strict_undefined**: throwOnUndefined=true
- **lockfile sha256** verified per template at runtime

## Flows (v14_2 default, v14_1 legacy)
- `flow.genesis.v14_2`
- `flow.growth.v14_2`
- `flow.content.v14_2`
- `flow.build_web.v14_2`
- `flow.deep_audit.v14_2`
- `flow.automation_suite.v14_2`

Fallbacks: corresponding `*.v14_1`.

## Input note
No `route.template_key` required. Router decides `flow_key`.
