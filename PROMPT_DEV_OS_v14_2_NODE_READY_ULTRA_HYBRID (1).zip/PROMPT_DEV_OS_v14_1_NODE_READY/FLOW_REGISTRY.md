# FLOW_REGISTRY (Templates in registry)

Listado de templates disponibles en `registry/registry.json`.

| key | title | short_desc | reads | path |
|---|---|---|---|---|
| `agent00.meta_archivist.v1` | — | — | — | `templates/agent00.meta_archivist.v1.j2` |
| `agent00.qc.v2` | — | — | — | `templates/agent00.qc.v2.j2` |
| `agent01.strategy.v1` | Estrategia | Define objetivos, posicionamiento, ICP, messaging, roadmap 30/60/90. | passthrough.inputs, source.documents, source.summaries | `templates/agent01.strategy.v1.j2` |
| `agent02.visual.v1` | Visual | Define identidad visual, moodboard textual, guidelines, prompts para imágenes. | passthrough.inputs, source.documents, source.summaries | `templates/agent02.visual.v1.j2` |
| `agent03.soul.v1` | Soul | Define tono, voz, valores, narrativa fundacional. | passthrough.inputs, source.documents, source.summaries | `templates/agent03.soul.v1.j2` |
| `agent04.landing.v1` | Landing | Estructura landing: hero, proof, features, FAQ, CTA, wireframe copy. | passthrough.inputs, source.documents, source.summaries | `templates/agent04.landing.v1.j2` |
| `agent05.metaprompt.v1` | Metaprompt | Crea prompts madre: variables, guardrails, formatos. | passthrough.inputs, source.documents, source.summaries | `templates/agent05.metaprompt.v1.j2` |
| `agent06.brand.v1` | Brand | Sistema de marca: arquetipo, diferenciales, pilares, tagline. | passthrough.inputs, source.documents, source.summaries | `templates/agent06.brand.v1.j2` |
| `agent07.sales_copy.v2` | Sales Copy | Copy de ventas: AIDA/PAS, objeciones, garantías prudentes. | passthrough.inputs, source.documents, source.summaries | `templates/agent07.sales_copy.v2.j2` |
| `agent08.growthhack.v1` | Growth Hack | Experimentos growth: hipótesis, canales, métricas, backlog. | passthrough.inputs, source.documents, source.summaries | `templates/agent08.growthhack.v1.j2` |
| `agent09.automate.v1` | Automate | Automatizaciones: triggers, actions, datos, errores, observabilidad. | passthrough.inputs, source.documents, source.summaries | `templates/agent09.automate.v1.j2` |
| `agent10.analytics.v1` | Analytics | Plan de analítica: eventos, KPIs, dashboards, UTMs. | passthrough.inputs, source.documents, source.summaries | `templates/agent10.analytics.v1.j2` |
| `agent11.seo.v1` | SEO | SEO plan: clusters, keywords, briefs, on-page, tech SEO. | passthrough.inputs, source.documents, source.summaries | `templates/agent11.seo.v1.j2` |
| `agent12.email.v1` | Email | Secuencias email: bienvenida, nurturing, reactivación, asuntos. | passthrough.inputs, source.documents, source.summaries | `templates/agent12.email.v1.j2` |
| `agent13.reels.v1` | Reels | Guiones cortos: hook, beats, CTA, b-roll, captions. | passthrough.inputs, source.documents, source.summaries | `templates/agent13.reels.v1.j2` |
| `agent14.youtube.v1` | YouTube | Guiones largos: estructura, capítulos, retención, thumbnails. | passthrough.inputs, source.documents, source.summaries | `templates/agent14.youtube.v1.j2` |
| `agent15.compliance.v2` | — | — | — | `templates/agent15.compliance.v2.j2` |
| `agent16.minibrand.v1` | MiniBrand | Resumen de marca: 1 página, quick rules. | passthrough.inputs, source.documents, source.summaries | `templates/agent16.minibrand.v1.j2` |
| `agent17.community.v1` | Community | Estrategia comunidad: formatos, normas, calendar, mod. | passthrough.inputs, source.documents, source.summaries | `templates/agent17.community.v1.j2` |
| `agent18.influencer.v1` | Influencer | Outreach: perfiles, briefs, contratos light, compliance. | passthrough.inputs, source.documents, source.summaries | `templates/agent18.influencer.v1.j2` |
| `agent19.ads.v1` | Ads | Creatividades/angles, copies, targeting, testing plan. | passthrough.inputs, source.documents, source.summaries | `templates/agent19.ads.v1.j2` |
| `agent20.crisis.v1` | Crisis | Playbook crisis: escenarios, mensajes, approvals, timelines. | passthrough.inputs, source.documents, source.summaries | `templates/agent20.crisis.v1.j2` |
| `agent21.press.v1` | Press | PR kit: press release, boilerplate, Q&A, media list. | passthrough.inputs, source.documents, source.summaries | `templates/agent21.press.v1.j2` |
| `agent22.legaldocs.v1` | LegalDocs | Docs: ToS/Privacy skeleton, disclaimers, clauses. | passthrough.inputs, source.documents, source.summaries | `templates/agent22.legaldocs.v1.j2` |
| `agent23.repurpose.v1` | Repurpose | Reutilización: 1 pieza -> 10 formatos, checklist. | passthrough.inputs, source.documents, source.summaries | `templates/agent23.repurpose.v1.j2` |
| `agent24.localize.v1` | Localize | Localización: idioma, cultura, moneda, claims locales. | passthrough.inputs, source.documents, source.summaries | `templates/agent24.localize.v1.j2` |
| `agent25.offer.v1` | Offer | Oferta: value prop, pricing, bonuses, risk reversal prudente. | passthrough.inputs, source.documents, source.summaries | `templates/agent25.offer.v1.j2` |
| `agent26.funnel.v1` | Funnel | Funnel: etapas, assets, medición, optimización. | passthrough.inputs, source.documents, source.summaries | `templates/agent26.funnel.v1.j2` |
| `agent27.monetization.v1` | Monetization | Modelos revenue, unit economics, pricing tests. | passthrough.inputs, source.documents, source.summaries | `templates/agent27.monetization.v1.j2` |
| `agent28.launch.v1` | Launch | Plan lanzamiento: fases, assets, KPIs, timeline. | passthrough.inputs, source.documents, source.summaries | `templates/agent28.launch.v1.j2` |
| `agent29.hiring.v1` | Hiring | Hiring pack: role scorecard, interview loop, JD. | passthrough.inputs, source.documents, source.summaries | `templates/agent29.hiring.v1.j2` |
| `agent30.support.v1` | Support | Soporte: macros, SOPs, SLAs, knowledge base. | passthrough.inputs, source.documents, source.summaries | `templates/agent30.support.v1.j2` |
| `agent31.spy.v1` | Spy | Competitive intel: matriz, positioning gaps, hypotheses. | passthrough.inputs, source.documents, source.summaries | `templates/agent31.spy.v1.j2` |
| `agent32.research.v1` | Research | Research: síntesis, supuestos, riesgos, fuentes. | passthrough.inputs, source.documents, source.summaries | `templates/agent32.research.v1.j2` |
| `agent33.uiux.v1` | UIUX | UI/UX: user flows, IA, componentes, heurísticas. | passthrough.inputs, source.documents, source.summaries | `templates/agent33.uiux.v1.j2` |
| `agent34.rn.v1` | React Native | Arquitectura RN, navegación, estado, performance. | passthrough.inputs, source.documents, source.summaries | `templates/agent34.rn.v1.j2` |
| `agent35.supabase.v1` | Supabase | Esquema DB, RLS, auth, edge functions. | passthrough.inputs, source.documents, source.summaries | `templates/agent35.supabase.v1.j2` |
| `agent36.nextjs.v1` | Next.js | Arquitectura Next, rutas, SSR/ISR, env, patterns. | passthrough.inputs, source.documents, source.summaries | `templates/agent36.nextjs.v1.j2` |
| `agent37.tests.v1` | Tests | Plan tests: unit/integration/e2e, casos, tooling. | passthrough.inputs, source.documents, source.summaries | `templates/agent37.tests.v1.j2` |
| `agent38.deploy.v1` | Deploy | Deploy: entornos, CI/CD, observabilidad, rollback. | passthrough.inputs, source.documents, source.summaries | `templates/agent38.deploy.v1.j2` |
| `agent39.api.v1` | API | API design: endpoints, auth, rate limit, errors. | passthrough.inputs, source.documents, source.summaries | `templates/agent39.api.v1.j2` |
| `agent41.finance.v1` | Finance | Modelo financiero: ingresos/costes, escenarios, KPIs. | passthrough.inputs, source.documents, source.summaries | `templates/agent41.finance.v1.j2` |
| `agent42.product.v1` | Product | PRD: problema, solución, MVP, roadmap, riesgos. | passthrough.inputs, source.documents, source.summaries | `templates/agent42.product.v1.j2` |
| `agent43.partner.v1` | Partner | Partnerships: targets, propuesta, terms, outreach. | passthrough.inputs, source.documents, source.summaries | `templates/agent43.partner.v1.j2` |
| `agent44.esg.v1` | ESG | ESG: políticas, reporting, iniciativas, riesgos. | passthrough.inputs, source.documents, source.summaries | `templates/agent44.esg.v1.j2` |
| `agent45.future.v1` | Future | Foresight: tendencias, bets, escenarios 12-24m. | passthrough.inputs, source.documents, source.summaries | `templates/agent45.future.v1.j2` |
| `agent46.template_registry_manager.v1` | TemplateRegistryMgr | Gestiona registry/lockfile: add/remove/freeze. | passthrough.inputs, source.documents, source.summaries | `templates/agent46.template_registry_manager.v1.j2` |
| `agent47.prefetch_executor.v1` | PrefetchExecutor | Ejecuta prefetch stubs según policy + budget. | passthrough.inputs, source.documents, source.summaries | `templates/agent47.prefetch_executor.v1.j2` |
| `agent48.render_engine.v1` | RenderEngine | Render determinista + valida lockfile + output map. | passthrough.inputs, source.documents, source.summaries | `templates/agent48.render_engine.v1.j2` |
| `flow.automation_suite.v14_1` | — | — | — | `templates/flow.automation_suite.v14_1.j2` |
| `flow.build_web.v14_1` | — | — | — | `templates/flow.build_web.v14_1.j2` |
| `flow.content.v14_1` | — | — | — | `templates/flow.content.v14_1.j2` |
| `flow.deep_audit.v14_1` | — | — | — | `templates/flow.deep_audit.v14_1.j2` |
| `flow.genesis.v14_1` | — | — | — | `templates/flow.genesis.v14_1.j2` |
| `flow.growth.v14_1` | — | — | — | `templates/flow.growth.v14_1.j2` |
| `kernel.prefetch_policy.v1` | — | — | system.route | `templates/kernel.prefetch_policy.v1.j2` |
| `kernel.render_policy.v1` | — | — | — | `templates/kernel.render_policy.v1.j2` |
| `kernel.router.v2` | — | — | passthrough.inputs | `templates/kernel.router.v2.j2` |
