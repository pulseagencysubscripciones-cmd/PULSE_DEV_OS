import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";

type AnyObj = Record<string, any>;
const ROOT = path.resolve(process.cwd());

function readJSON(p: string): AnyObj {
  return JSON.parse(fs.readFileSync(p, "utf-8"));
}
function writeJSON(p: string, obj: any) {
  fs.writeFileSync(p, JSON.stringify(obj, null, 2));
}
function sha256(text: string): string {
  return crypto.createHash("sha256").update(text, "utf-8").digest("hex");
}

function main() {
  const regPath = path.join(ROOT, "registry", "registry.json");
  const lockPath = path.join(ROOT, "registry", "lockfile.lock.json");
  const registry = readJSON(regPath);
  const lock = readJSON(lockPath).TEMPLATE_LOCKFILE;

  for (const k of Object.keys(registry)) {
    const meta = registry[k];
    const tplPath = path.join(ROOT, meta.path);
    const text = fs.readFileSync(tplPath, "utf-8");
    lock[k] = lock[k] ?? {};
    lock[k].version = meta.version;
    lock[k].hash = "sha256:" + sha256(text);
    lock[k].required_vars = meta.required_vars ?? [];
    lock[k].optional_vars = meta.optional_vars ?? [];
  }

  writeJSON(lockPath, { TEMPLATE_LOCKFILE: lock });
  console.log("Lockfile frozen (sha256 updated).");
}

main();
