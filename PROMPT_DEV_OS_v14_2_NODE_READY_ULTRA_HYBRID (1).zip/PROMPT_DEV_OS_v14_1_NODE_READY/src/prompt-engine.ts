import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import Ajv from "ajv";
import nunjucks from "nunjucks";

type AnyObj = Record<string, any>;

const ROOT = path.resolve(process.cwd());

function readJSON(p: string): AnyObj {
  return JSON.parse(fs.readFileSync(p, "utf-8"));
}

function sha256(text: string): string {
  return crypto.createHash("sha256").update(text, "utf-8").digest("hex");
}

function assert(condition: any, msg: string): asserts condition {
  if (!condition) throw new Error(msg);
}

function loadRegistry() {
  const regPath = path.join(ROOT, "registry", "registry.json");
  const lockPath = path.join(ROOT, "registry", "lockfile.lock.json");
  const registry = readJSON(regPath) as AnyObj;
  const lockfile = readJSON(lockPath).TEMPLATE_LOCKFILE as AnyObj;
  return { registry, lockfile };
}

function verifyTemplate(key: string, registry: AnyObj, lockfile: AnyObj) {
  const meta = registry[key];
  assert(meta, `Template not in registry: ${key}`);
  const tplPath = path.join(ROOT, meta.path);
  const tplText = fs.readFileSync(tplPath, "utf-8");
  const expected = lockfile[key]?.hash;
  assert(expected, `Template not in lockfile: ${key}`);
  const actual = "sha256:" + sha256(tplText);
  assert(actual === expected, `Hash mismatch for ${key}. Expected ${expected}, got ${actual}`);
  return { tplPath, tplText };
}

function makeEnv() {
  // Nunjucks is Jinja-like; we configure strict undefined.
  const env = new nunjucks.Environment(new nunjucks.FileSystemLoader(ROOT), {
    autoescape: true,
    throwOnUndefined: true,
    trimBlocks: true,
    lstripBlocks: true
  });
  // Filters (whitelist concept)
  env.addFilter("tojson", (obj: any) => JSON.stringify(obj, null, 2));
  env.addFilter("lower", (s: any) => String(s ?? "").toLowerCase());
  return env;
}

// ---- Prefetch stubs (replace with real tools) ----
async function tools_memory_fetch(_ctx: AnyObj) {
  return { memories: [] };
}
async function tools_docs_fetch(_ctx: AnyObj) {
  return { documents: [] };
}
async function tools_tools_catalog_fetch(_ctx: AnyObj) {
  return { tools_catalog: ["memory.fetch", "docs.fetch"] };
}

async function runPrefetch(policy: AnyObj, ctx: AnyObj) {
  const tools: string[] = policy.tools ?? [];
  const results: AnyObj = {};
  for (const t of tools.slice(0, ctx.system.runtime.tool_budget.max_tools ?? 2)) {
    if (t === "tools.memory.fetch") Object.assign(results, await tools_memory_fetch(ctx));
    if (t === "tools.docs.fetch") Object.assign(results, await tools_docs_fetch(ctx));
    if (t === "tools.tools_catalog.fetch") Object.assign(results, await tools_tools_catalog_fetch(ctx));
  }
  return results;
}

function parseJSONSafe(text: string): AnyObj {
  try { return JSON.parse(text); } catch { return {}; }
}

// ---- Pipeline mapping ----
const FLOW_PIPELINES: Record<string, string[]> = {
  // v14_2 (default)
  "flow.genesis.v14_2": [
    "agent16.minibrand.v1",
    "agent01.strategy.v1",
    "agent25.offer.v1",
    "agent04.landing.v1",
    "agent07.sales_copy.v2"
  ],
  "flow.growth.v14_2": [
    "agent08.growthhack.v1",
    "agent26.funnel.v1",
    "agent19.ads.v1",
    "agent10.analytics.v1"
  ],
  "flow.content.v14_2": [
    "agent03.soul.v1",
    "agent13.reels.v1",
    "agent14.youtube.v1",
    "agent21.press.v1",
    "agent18.influencer.v1"
  ],
  "flow.build_web.v14_2": [
    "agent33.uiux.v1",
    "agent36.nextjs.v1",
    "agent35.supabase.v1",
    "agent39.api.v1",
    "agent37.tests.v1",
    "agent38.deploy.v1"
  ],
  "flow.deep_audit.v14_2": [
    "agent31.spy.v1",
    "agent32.research.v1",
    "agent11.seo.v1",
    "agent10.analytics.v1"
  ],
  "flow.automation_suite.v14_2": [
    "agent09.automate.v1",
    "agent30.support.v1",
    "agent29.hiring.v1"
  ],

  // v14_1 (legacy)
  "flow.genesis.v14_1": [
    "agent01.strategy.v1",
    "agent06.brand.v1",
    "agent16.minibrand.v1",
    "agent05.metaprompt.v1"
  ],
  "flow.growth.v14_1": [
    "agent25.offer.v1",
    "agent26.funnel.v1",
    "agent19.ads.v1",
    "agent12.email.v1",
    "agent10.analytics.v1"
  ],
  "flow.content.v14_1": [
    "agent03.soul.v1",
    "agent07.sales_copy.v2",
    "agent13.reels.v1",
    "agent14.youtube.v1",
    "agent23.repurpose.v1"
  ],
  "flow.build_web.v14_1": [
    "agent32.research.v1",
    "agent33.uiux.v1",
    "agent36.nextjs.v1",
    "agent35.supabase.v1",
    "agent39.api.v1",
    "agent37.tests.v1",
    "agent38.deploy.v1"
  ],
  "flow.deep_audit.v14_1": [
    "agent31.spy.v1",
    "agent10.analytics.v1",
    "agent11.seo.v1",
    "agent15.compliance.v2"
  ],
  "flow.automation_suite.v14_1": [
    "agent09.automate.v1",
    "agent30.support.v1",
    "agent10.analytics.v1"
  ],
  "flow.templates.v14_1": [
    "agent46.template_registry_manager.v1"
  ],
  "flow.export_state.v14_1": [
    "agent00.meta_archivist.v1"
  ]
};

const INTENT_TO_FLOW: Record<string, string> = {
  "genesis":"flow.genesis.v14_2",
  "growth":"flow.growth.v14_2",
  "content":"flow.content.v14_2",
  "build_web":"flow.build_web.v14_2",
  "deep_audit":"flow.deep_audit.v14_2",
  "automation_suite":"flow.automation_suite.v14_2",
  "templates":"flow.templates.v14_1",
  "export_state":"flow.export_state.v14_1"
};

// ---- Main ----
async function main() {
  const inputPath = process.argv[2];
  assert(inputPath, "Usage: ts-node src/prompt-engine.ts <project.json>");

  // Validate input
  const schemaPath = path.join(ROOT, "schemas", "schema.os.v14_1.json");
  const schema = readJSON(schemaPath);
  const ajv = new Ajv({ allErrors: true, strict: false });
  const validate = ajv.compile(schema);

  const project = readJSON(path.resolve(inputPath));
  assert(validate(project), "Schema validation failed: " + JSON.stringify(validate.errors, null, 2));

  // Build initial ctx
  const ctx: AnyObj = {
    system: {
      runtime: {
        tool_budget: project?.system?.runtime?.tool_budget ?? { max_tools: 2, max_latency_ms: 800 }
      },
      route: {}
    },
    passthrough: { inputs: project.inputs },
    source: project.source ?? {},
    tools: project.tools ?? {}
  };

  const { registry, lockfile } = loadRegistry();
  const env = makeEnv();

  // 1) Router decides flow automatically (no template_key required)
  verifyTemplate("kernel.router.v2", registry, lockfile);
  const routerRendered = env.render(registry["kernel.router.v2"].path, ctx);
  const route = parseJSONSafe(routerRendered);
  ctx.system.route = route;
  const flowKey = route.flow_key ?? INTENT_TO_FLOW[route.intent] ?? "flow.genesis.v14_2";
  ctx.system.route.flow_key = flowKey;

  // 2) Prefetch policy + prefetch execution
  verifyTemplate("kernel.prefetch_policy.v1", registry, lockfile);
  const prefetchPolicyText = env.render(registry["kernel.prefetch_policy.v1"].path, ctx);
  const prefetchPolicy = parseJSONSafe(prefetchPolicyText);
  const prefetchResults = await runPrefetch(prefetchPolicy, ctx);

  // Merge prefetch into ctx.source (sanitized/minimal)
  ctx.source = {
    ...ctx.source,
    summaries: prefetchResults.memories ?? ctx.source.summaries,
    documents: prefetchResults.documents ?? ctx.source.documents,
    tools_catalog: prefetchResults.tools_catalog ?? ctx.source.tools_catalog
  };

  // 3) Pipeline execution (flow -> agents)
  const pipeline = FLOW_PIPELINES[flowKey] ?? FLOW_PIPELINES["flow.genesis.v14_2"];
  const executed: string[] = [];
  const outputs: AnyObj = {};

  for (const key of pipeline) {
    verifyTemplate(key, registry, lockfile);
    const rendered = env.render(registry[key].path, ctx);
    executed.push(key);
    outputs[key] = rendered;
    // Accumulate summaries lightly for subsequent agents
    ctx.source.summaries = (ctx.source.summaries ?? []).concat([{ template: key, excerpt: rendered.slice(0, 800) }]);
  }

  // 4) QA gate
  verifyTemplate("agent00.qc.v2", registry, lockfile);
  const qaOut = env.render(registry["agent00.qc.v2"].path, ctx);
  outputs["agent00.qc.v2"] = qaOut;
  executed.push("agent00.qc.v2");

  // 5) Compliance gate
  verifyTemplate("agent15.compliance.v2", registry, lockfile);
  const compOut = env.render(registry["agent15.compliance.v2"].path, ctx);
  outputs["agent15.compliance.v2"] = compOut;
  executed.push("agent15.compliance.v2");

  // 6) Meta archivist snapshot
  verifyTemplate("agent00.meta_archivist.v1", registry, lockfile);
  const snapshot = {
    timestamp: new Date().toISOString(),
    route: ctx.system.route,
    selected_flow: flowKey,
    executed_templates: executed,
    lockfile_verified: true,
    outputs_manifest: Object.keys(outputs)
  };
  outputs["agent00.meta_archivist.v1"] = JSON.stringify(snapshot, null, 2);
  executed.push("agent00.meta_archivist.v1");

  // Final output (single markdown)
  const md = [
    `# PROMPT_DEV_OS_v14_2_ULTRA_HYBRID — OUTPUT`,
    ``,
    `## Route`,
    "```json",
    JSON.stringify(ctx.system.route, null, 2),
    "```",
    ``,
    `## Flow`,
    `**${flowKey}**`,
    ``,
    `## Pipeline outputs`,
    ...pipeline.map(k => `### ${k}\n\n${outputs[k]}`),
    ``,
    `## QA`,
    "```",
    outputs["agent00.qc.v2"],
    "```",
    ``,
    `## Compliance`,
    "```",
    outputs["agent15.compliance.v2"],
    "```",
    ``,
    `## Export State`,
    "```json",
    outputs["agent00.meta_archivist.v1"],
    "```"
  ].join("\n");

  console.log(md);
}

main().catch(e => {
  console.error("FATAL:", e?.message ?? e);
  process.exit(1);
});
