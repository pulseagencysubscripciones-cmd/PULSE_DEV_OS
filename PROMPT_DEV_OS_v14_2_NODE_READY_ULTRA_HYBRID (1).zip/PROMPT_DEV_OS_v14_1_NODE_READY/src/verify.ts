import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";

type AnyObj = Record<string, any>;
const ROOT = path.resolve(process.cwd());

function readJSON(p: string): AnyObj {
  return JSON.parse(fs.readFileSync(p, "utf-8"));
}
function sha256(text: string): string {
  return crypto.createHash("sha256").update(text, "utf-8").digest("hex");
}
function assert(cond: any, msg: string): asserts cond {
  if (!cond) throw new Error(msg);
}

function main() {
  const registry = readJSON(path.join(ROOT, "registry", "registry.json"));
  const lockfile = readJSON(path.join(ROOT, "registry", "lockfile.lock.json")).TEMPLATE_LOCKFILE;

  const keys = Object.keys(registry);
  for (const k of keys) {
    const meta = registry[k];
    const tplPath = path.join(ROOT, meta.path);
    assert(fs.existsSync(tplPath), `Missing template file: ${meta.path}`);
    const text = fs.readFileSync(tplPath, "utf-8");
    const expected = lockfile[k]?.hash;
    assert(expected, `Missing lock entry: ${k}`);
    const actual = "sha256:" + sha256(text);
    assert(actual === expected, `Hash mismatch: ${k}`);
  }
  console.log(`OK: verified ${keys.length} templates.`);
}

main();
