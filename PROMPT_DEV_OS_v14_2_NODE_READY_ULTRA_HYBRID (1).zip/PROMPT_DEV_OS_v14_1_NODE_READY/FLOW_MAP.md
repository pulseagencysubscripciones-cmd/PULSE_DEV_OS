# FLOW_MAP (v14_2 default)

## v14_2 flows → pipeline (agents in order)

### flow.genesis.v14_2
1. agent16.minibrand.v1
2. agent01.strategy.v1
3. agent25.offer.v1
4. agent04.landing.v1
5. agent07.sales_copy.v2

### flow.growth.v14_2
1. agent08.growthhack.v1
2. agent26.funnel.v1
3. agent19.ads.v1
4. agent10.analytics.v1

### flow.content.v14_2
1. agent03.soul.v1
2. agent13.reels.v1
3. agent14.youtube.v1
4. agent21.press.v1
5. agent18.influencer.v1

### flow.build_web.v14_2
1. agent33.uiux.v1
2. agent36.nextjs.v1
3. agent35.supabase.v1
4. agent39.api.v1
5. agent37.tests.v1
6. agent38.deploy.v1

### flow.deep_audit.v14_2
1. agent31.spy.v1
2. agent32.research.v1
3. agent11.seo.v1
4. agent10.analytics.v1

### flow.automation_suite.v14_2
1. agent09.automate.v1
2. agent30.support.v1
3. agent29.hiring.v1

## Gates (always appended after pipeline)
- agent00.qc.v2
- agent15.compliance.v2
- agent00.meta_archivist.v1 (snapshot)
