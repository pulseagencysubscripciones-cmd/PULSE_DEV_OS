# ROUTER_RULES (kernel.router.v2)

## Goal
Choose `system.route.flow_key` automatically (no template_key in input).

## Signals (heuristics)
- **templates/menu/export**: command-like tokens (`!menu`, `@templates`, `@export_state`)
- **audit**: auditoría, diagnóstico, SEO, research → deep_audit
- **automation**: automatización, SOP, Zapier/Make → automation_suite
- **build**: web/app/Next.js/Supabase/API/deploy → build_web
- **growth**: growth, ads, funnel, CAC, activación → growth
- **content**: reels, youtube, guiones, copy, PR, influencers → content
- **fallback**: genesis

## Output contract
Router MUST output JSON with:
- `intent`
- `flow_key` (prefer v14_2)
- `confidence` (0..1)
- `rationale` (array of bullets)
- `fallback` (alt flow_key + reason)

## Fallback policy
If ambiguous → `flow.genesis.v14_2`, fallback `flow.genesis.v14_1`.
